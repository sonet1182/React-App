import React from "react";
import {Link} from 'react-router-dom';


const Profile = () => {

    return (
      <h1>I am Profile</h1>
    );

}

export default Profile;