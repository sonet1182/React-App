import React from "react";
import {Link} from 'react-router-dom';
import Navbar from "../../../layouts/frontend/Navbar";


function Login() {

    return (
        <div>
            <Navbar></Navbar>
            

                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-md-6">
                        <div className="card">
                            <div className="card-header">
                                <h4>Login</h4>
                            </div>
                            <div className="card-body">
                                <form>
                                    
                                    <div class="form-group mb-3">
                                        <label for="exampleInputEmail1">Email address</label>
                                        <input type="email" name="address" class="form-control"  aria-describedby="emailHelp" placeholder="Enter email"/>
                                        
                                    </div>
                                    <div class="form-group mb-3">
                                        <label for="exampleInputPassword1">Password</label>
                                        <input type="password" name="password" class="form-control"  placeholder="Password"/>
                                    </div>
                                    
                                    
                                    <button type="submit" class="btn btn-primary">Login</button>
                                </form>
                            </div>

                            </div>

                        </div>
                    </div>

                

                
            </div>
        
        
        </div>
    );

}

export default Login;