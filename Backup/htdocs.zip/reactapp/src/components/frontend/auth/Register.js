import React, {useState} from "react";
import {Link} from 'react-router-dom';
import Navbar from "../../../layouts/frontend/Navbar";


function Register() {

    const [registerInput, setstate] = useState({
        name: '',
        email: '',
        password: '',
    });

    const handleInput = (e) => {
        e.persist();
        setRegister({...registerInput, [e.target.name]: e.target.value});
    }

    const registerSubmit = (e) => {
        e.preventDefault();
        const data = {
            name: registerInput.name,
            email: registerInput.email,
            password: registerInput.password,
        }
    }


    return (
        <div>
            <Navbar></Navbar>
            

                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-md-6">
                        <div className="card">
                            <div className="card-header">
                                <h4>Register</h4>
                            </div>
                            <div className="card-body">
                                <form onSubmit={registerSubmit}>
                                    <div class="form-group mb-3">
                                        <label for="exampleInputEmail1">Name</label>
                                        <input type="text" name="name" class="form-control" onChange={handleInput} value={registerInput.name}  placeholder="Enter Name" />
                                        
                                    </div>
                                    <div class="form-group mb-3">
                                        <label for="exampleInputEmail1">Email address</label>
                                        <input type="email" name="address" class="form-control" onChange={handleInput} value={registerInput.email} placeholder="Enter email"/>
                                        
                                    </div>
                                    <div class="form-group mb-3">
                                        <label for="exampleInputPassword1">Password</label>
                                        <input type="password" name="password" class="form-control" onChange={handleInput} value={registerInput.password}  placeholder="Password"/>
                                    </div>
                                    
                                    
                                    <button type="submit" class="btn btn-primary">Register</button>
                                </form>
                            </div>

                            </div>

                        </div>
                    </div>

                

                
            </div>
        
        
        </div>
    );

}

export default Register;