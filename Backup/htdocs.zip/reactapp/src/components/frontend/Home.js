import React from "react";
import {Link} from 'react-router-dom';
import Navbar from "../../layouts/frontend/Navbar";


const Home = () => {

    return (
        <div>
            <Navbar></Navbar>
        </div>
    );

}

export default Home;